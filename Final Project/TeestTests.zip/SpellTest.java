import org.junit.Test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;

public class SpellTest {

	
		@Test
		public void testSpell() {
			
			Fighter testFighter = new Fighter("Test Fighter",4,5);
			
			Stat testStat = new Stat(testFighter,"Test Stat",2);
			
			Spell testSpell = new Spell("Test Name", 7, testStat, "Test [i], [d], [t]", false);
			
			assertEquals("Test Name", testSpell.getName());
			
			assertEquals("Test Stat",
					testSpell.getImplement());
			
			assertEquals(1, testSpell.getId());
			
			assertEquals(7, testSpell.getCost());
			
			assertEquals("Test Test Stat, [d], [t]", testSpell.getMessage());
			
			assertEquals("Test Test Stat, 14, [t]", testSpell.getMessage(14));
			
			assertEquals("Test Test Stat, 14, Test Fighter", testSpell.getMessage(14, testFighter));
			
			assertTrue(!(testSpell.isLearned()));
			
			assertEquals(testStat, testSpell.getStat());
			
			assertEquals(testFighter, testSpell.getUser());
			
			assertTrue(Action.anyLearned());
			
			assertEquals(1, Action.totalActions());
			
			assertEquals(Action.getAction(1), testSpell);
			
			assertEquals(Action.getAction("Test Name"), testSpell);
			
			assertEquals(Action.findAction(0), testSpell);
			
			assertTrue(!(Spell.anyLearned()));
			
			assertTrue(!(testSpell.isUsable()));
			
			assertEquals("[UNLEARNED]", testSpell.menuMessage());
			
			assertEquals(0, Spell.getMaxMana());
			
			assertEquals(0, Spell.getMana());
			
			testSpell.learn();
			
			assertTrue(testSpell.isLearned());
			
			assertTrue(Spell.anyLearned());
			
			assertEquals("Test Name (Insufficient Mana!)", testSpell.menuMessage());
			
			assertTrue(!(testSpell.isUsable()));
			
			Spell.setMaxMana(13);
			
			assertEquals(13, Spell.getMaxMana());
			
			assertEquals(13, Spell.getMana());

			assertEquals("Test Name (Mana cost: 7)", testSpell.menuMessage());
			
			assertTrue(testSpell.isUsable());
			
			assertTrue(!(Spell.manaSpent()));
			
			assertEquals(testSpell.getMessage(15, testFighter), testSpell.quickUse(15, testFighter));
			
			assertEquals(13, Spell.getMaxMana());
			
			assertEquals(6, Spell.getMana());
			
			assertEquals("6/13", Spell.manaGauge());

			assertTrue(!(testSpell.isUsable()));
			
			assertTrue(Spell.manaSpent());			
		}
}
