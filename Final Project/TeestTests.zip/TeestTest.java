import org.junit.Test;

import static org.junit.Assert.*;

import java.util.ArrayList;

public class TeestTest {
	
		@Test
		public void testTeest() {
		//please input values to satisfy the prompts.
			assertTrue(inputTester(1, 7, (Teest.boundedInput("Enter between 1 and 7 : ", 1, 7))));
			
			assertTrue(inputTester(1, 4, Teest.mainScreen()));
			
			Stat testStat = new Stat((new Fighter()), "Test Stat", 1);
			
			ArrayList<Action> testList = Teest.spellBuilder(testStat);

			assertTrue(Teest.listUnlearned(testList));
			
			Teest.learnAction(testStat, testList);
			
			assertTrue(!(Teest.listUnlearned(testList)));
		}
		
		public static boolean inputTester(int min, int max, int input) {
			
			if ((input >= min) && (input <= max)) {
				
				return true;
			} else {
				
				return false;
			}
		}
}
