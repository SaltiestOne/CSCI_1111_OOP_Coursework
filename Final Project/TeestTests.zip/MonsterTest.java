import org.junit.Test;

import static org.junit.Assert.*;

public class MonsterTest {

		@Test
		public void testMonster() {
			
			Monster testMonster = new Monster((new String[] {"Test Name", "Test Verb", "Test Critical",			
					"Test Flavor 1", "Test Flavor 2"}), 5, 10);
			
			assertEquals("Test Name", testMonster.getName());
			
			assertEquals(5, testMonster.getLevel());
			
			assertEquals(10, testMonster.getMaxHealth());
			
			assertEquals(10, testMonster.getHealth());
			
			assertEquals("10/10", testMonster.healthGauge());
			
			assertEquals(4, testMonster.harm(4));
			
			assertEquals(6, testMonster.getHealth());
			
			assertEquals(2, testMonster.heal(2));
			
			assertEquals(8, testMonster.getHealth());
			
			assertEquals("Test Flavor 1\nTest Flavor 2\n", testMonster.getFlavor());
			
			assertEquals(0, testMonster.getDamage());
			
			testMonster.setDamage(5);
			
			assertEquals(5, testMonster.getDamage());
			
			for (int t = 0; t < 100; t++) {
				
				testMonster.setDamage();
				
				assertTrue((testMonster.getDamage()) >= 1);
				
				assertTrue((testMonster.getDamage()) <= 13);				
			}	
		}
}