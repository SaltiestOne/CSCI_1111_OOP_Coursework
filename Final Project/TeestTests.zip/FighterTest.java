import org.junit.Test;

import static org.junit.Assert.*;

public class FighterTest {

		@Test
		public void testFighter() {
			
			Fighter testFighter = new Fighter("Test Name", 1, 10);
			
			assertEquals("Test Name", testFighter.getName());
			
			assertEquals(1, testFighter.getLevel());
			
			assertEquals(10, testFighter.getMaxHealth());
			
			assertEquals(10, testFighter.getHealth());
			
			assertEquals("10/10", testFighter.healthGauge());
			
			assertEquals(4, testFighter.harm(4));
			
			assertEquals(6, testFighter.getHealth());
			
			assertEquals(2, testFighter.heal(2));
			
			assertEquals(8, testFighter.getHealth());
			
			for (int t = 0; t < 100; t++) {
				
				int damageTest = Fighter.damage(7, 8);
				
				assertTrue(damageTest >= 7);
				
				assertTrue(damageTest <= 15);				
			}		
		}
}