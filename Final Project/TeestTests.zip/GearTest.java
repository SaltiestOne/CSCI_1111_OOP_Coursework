import org.junit.Test;

import static org.junit.Assert.*;

public class GearTest {

	@Test
	public void testGear() {
		
		Fighter testFighter = new Fighter("Test Fighter", 1, 10);
		
		Gear testGear = new Gear(testFighter, "Test Stat", 2, (new String[] {"Implement 1", "Implement 2"}));
		
		assertEquals(testFighter, testGear.getUser());
		
		assertEquals("Test Stat", testGear.getName());
		
		assertEquals(2, testGear.getLevel());
		
		assertEquals("Implement 1", testGear.levelName());
		
		assertTrue(testGear.upItem());
		
		assertEquals("Implement 2", testGear.levelName());
		
		assertTrue(!(testGear.upItem()));
		
		assertEquals(5, testGear.getModdedLevel());
		
		testGear.setLevel(4);
		
		assertEquals(4, testGear.getLevel());
		
		assertEquals(9, testGear.getModdedLevel());
	}
}
