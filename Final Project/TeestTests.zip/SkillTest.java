import org.junit.Test;

import static org.junit.Assert.*;

public class SkillTest {

	
		@Test
		public void testSkill() {
			
			Fighter testFighter = new Fighter("Test Fighter",4,5);
			
			Gear testGear = new Gear(testFighter, "Test Gear", 2, (new String[] {"Test Implement"}));
			
			Skill testSkill = new Skill("Test Name", 7, testGear, "Test [i], [d], [t]", false);
			
			assertEquals("Test Name", testSkill.getName());
			
			assertEquals("Test Implement",
					testSkill.getImplement());
			
			assertEquals(1, testSkill.getId());
			
			assertEquals(7, testSkill.getCost());
			
			assertEquals("Test Test Implement, [d], [t]", testSkill.getMessage());
			
			assertEquals("Test Test Implement, 14, [t]", testSkill.getMessage(14));
			
			assertEquals("Test Test Implement, 14, Test Fighter", testSkill.getMessage(14, testFighter));
			
			assertTrue(!(testSkill.isLearned()));
			
			assertEquals(testGear, testSkill.getStat());
			
			assertEquals(testFighter, testSkill.getUser());

			assertEquals(1, Action.totalActions());
			
			assertEquals(Action.getAction(1), testSkill);
			
			assertEquals(Action.getAction("Test Name"), testSkill);
			
			assertEquals(Action.findAction(0), testSkill);
			
			assertTrue(!(Skill.isOnCooldown()));
			
			assertEquals(0, Skill.getCooldown());
			
			assertTrue(!(testSkill.isUsable()));
			
			assertEquals("[UNLEARNED]", testSkill.menuMessage());
			
			testSkill.learn();
			
			assertTrue(testSkill.isLearned());
			
			assertTrue(testSkill.isUsable());
			
			assertEquals("Test Name (Test Implement, Cooldown 6)", testSkill.menuMessage());
			
			assertEquals(testSkill.getMessage(15, testFighter), testSkill.quickUse(15, testFighter));
			
			assertEquals(7, Skill.getCooldown());
			
			assertTrue(Skill.isOnCooldown());
			
			assertTrue(!(testSkill.isUsable()));

		}
}
