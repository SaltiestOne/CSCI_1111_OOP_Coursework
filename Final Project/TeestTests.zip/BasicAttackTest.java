import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class BasicAttackTest {
	
	
	@Test
	public void testBasic() {
		
		Fighter testFighter = new Fighter("Test Fighter",4,5);
		
		Gear testGear = new Gear(testFighter, "Test Gear", 2, (new String[] {"Test Implement"}));
		
		BasicAttack testBasic = new BasicAttack(testGear, "Test [i], [d], [t]");
		
		assertEquals("Basic Attack", testBasic.getName());
		
		assertEquals("Test Implement",
				testBasic.getImplement());
		
		assertEquals(0, testBasic.getId());
		
		assertEquals(0, testBasic.getCost());
		
		assertEquals("Test Test Implement, [d], [t]", testBasic.getMessage());
		
		assertEquals("Test Test Implement, 14, [t]", testBasic.getMessage(14));
		
		assertEquals("Test Test Implement, 14, Test Fighter", testBasic.getMessage(14, testFighter));
		
		assertTrue(testBasic.isLearned());
		
		assertEquals(testGear, testBasic.getStat());
		
		assertEquals(testFighter, testBasic.getUser());
		
		assertEquals(0, Action.totalActions());
		
		assertTrue(!(Action.anyLearned()));
		
		assertTrue(!(Skill.isOnCooldown()));
		
		assertEquals(0, Skill.getCooldown());
		
		assertTrue(testBasic.isUsable());
		
		assertEquals(testBasic.getName(), testBasic.menuMessage());

		assertEquals(testBasic.getMessage(15, testFighter), testBasic.quickUse(15, testFighter));
		
		assertEquals(0, Skill.getCooldown());
		
		assertTrue(!(Skill.isOnCooldown()));
		
		assertTrue(testBasic.isUsable());
	}
}
