import org.junit.Test;

import static org.junit.Assert.*;

public class StatTest {

	@Test
	public void testStat() {
		
		Fighter testFighter = new Fighter("Test Fighter", 1, 10);
		
		Stat testStat = new Stat(testFighter, "Test Stat", 2);
		
		assertEquals(testFighter, testStat.getUser());
		
		assertEquals("Test Stat", testStat.getName());
		
		assertEquals(2, testStat.getLevel());
		
		assertEquals("Level 2", testStat.levelName());
		
		assertEquals(5, testStat.getModdedLevel());
		
		testStat.setLevel(4);
		
		assertEquals(4, testStat.getLevel());
		
		assertEquals("Level 4", testStat.levelName());
		
		assertEquals(9, testStat.getModdedLevel());
	}
}
