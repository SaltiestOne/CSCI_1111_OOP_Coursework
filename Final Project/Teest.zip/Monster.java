import java.util.Random;

/**
 * Subclass of Fighter representing the enemies that the
 * Hero will fight. Requires a String array for its constructor,
 * which includes its name, attack verbs, and a flavorful decription.
 * (How "monstrous" some of these enemies are will be left for the 
 * reader's ideology to determine).
 * 
 * @author Kayden Barlow
 */
class Monster extends Fighter {
	
	private String[] flavor;
	private int damage;
	private boolean stunned = false;
	
	/**
	 * Constructor for instances of the Monster
	 * class. This includes a String array for 
	 * the name, attack and critical verbs, and 
	 * flavor text of the Monster, as well it's 
	 * level and initial health. 
	 * 
	 * @param flavor A String array at least 5 Strings long,
	 * containing, in order: [0] Name, [1] Basic Attack verb,
	 * [2] Critical hit verb, and [3]/[4] two lines of
	 * flavor text. 
	 * @param level An integer representing the monster's level.
	 * @param maxHealth An integer representing the monster's max/initial health.
	 */
	Monster(String[] flavor, int level, int maxHealth) {
		
		super(flavor[0], level, maxHealth);
		
		this.flavor = flavor;
	}
	
	
	/**
	 * Outputs the monster's flavor text.
	 * 
	 * @return Two lines of flavor text.
	 */
	String getFlavor() {
		
		return (flavor[3] + "\n" + flavor[4] + "\n");
	}
	
	
	/**
	 * Returns the current Damage value
	 * for this Monster.
	 * 
	 * @return Integer damage parameter.
	 */
	int getDamage() {
		
		return this.damage;
	}
	
	
	/**
	 * Creates an int value representing the intended
	 * amount of damage for an enemy, which is a random
	 * number scaling based on the monster's level. 
	 * This number has a floor of one, and a ceiling 
	 * which scales faster than the player's normal damage
	 * number should. This is to create a more "random"
	 * damage amount for enemies.
	 * 
	 * @return Randomly-generated integer.
	 */
	void setDamage() {
		
		this.damage = (new Random().nextInt(3 + (int)(1.8 * (this.getLevel()))) + 1);
	}
	
	
	/**
	 * Sets the Monster's damage parameter to the
	 * input value. Damage cannot be negative.
	 * If it is set to zero, Monster is stunned,
	 * and damage is recalculated as if normal 
	 * (in case a critical overrides the stun).
	 * 
	 * @param damage Integer value of the
	 * Monster's new damage parameter.
	 */
	void setDamage(int damage) {
		
		if (damage <= 0) {
			
			this.setDamage();
			
			this.stun();
		} else {
		
			this.damage = damage;
		}
	}
	
	
	/**
	 * Causes the monster to be stunned, negating one
	 * turn: either the monster will be unable to take
	 * its next normal attack, or it will "downgrade" a 
	 * critical hit to a normal attack.
	 */
	void stun() {
		
		this.stunned = true;
	}
	
	
	/**
	 * The monster's "normal attack." This is 
	 * contained natively in a method as I currently have
	 * no need to make the monsters do anything but attack.
	 * If the monster is Stunned, it is unable to act and 
	 * the Stunned value is made false afterwards. Otherwise,
	 * an integer is called from the Damage method and 
	 * dealt to the target. In either case, flavor text is 
	 * printed, using the monster and targets' names and 
	 * the monster's attack verb where needed.
	 * 
	 * @param target Fighter targeted by the damage of
	 * the Monster's attack.
	 */
	void action(Fighter target) {
		
		if (stunned) {
		//i put these in the object just to make things easier
			System.out.printf("The %s is unable to harm the %s.\n\n",this.getName(),target.getName());
			
			this.stunned = false;
		} else {
		
			System.out.printf("The %s %s you,\n and you receive %d damage.\n",
					this.getName(),this.flavor[1],this.damage);
			
			target.harm(this.damage);
		}
	}
	
	
	/**
	 * Facilitates an enemy landing a "critical hit," 
	 * which deals double damage from normal and has a 
	 * different flavor message. This must be triggered 
	 * from a method in the main, as no internal methods 
	 * call for it. Has an additional interaction with the
	 * Stun boolean: scoring a critical while stunned will 
	 * "cancel out" both, ending the stun and calling for 
	 * the normal action method.
	 * 
	 * @param target Fighter targeted by the damage 
	 * from the critical hit.
	 */
	void critical(Fighter target) {
		
		if(stunned)	{
			
			this.stunned = false;
			//getting a critical will "override" a stun but causes the attack to be normal
			this.action(target);
		} else {
		
			int damage = (2 * this.damage);
			
			System.out.printf("Critical hit! The %s\n %s you for %d damage.\n",
					this.getName(),this.flavor[2],damage);
			//I thought an abnormal message would make it stand out
			target.harm(damage);
		}
	}
}