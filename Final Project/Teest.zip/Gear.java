/**
 * A subclass of Stat representing more
 * tangible traits of a Fighter, namely
 * specific tools (or categories of tools)
 * at the Fighter's disposal. Differs from
 * its parent in output naming and formatting,
 * but not in scaling.
 * 
 * @author Kayden Barlow
 */
class Gear extends Stat {
	
	private String[] items;
	private int itemLevel;

	/**
	 * Constructor for instances of the Gear
	 * class. Must be assigned to an 
	 * instance of the Fighter class.
	 * May be used to define instances of the
	 * Action class, with some potentially 
	 * requiring this specific subclass. 
	 * Requires a String array of one or more
	 * "implements" which the Gear object is
	 * meant to represent. An "itemLevel"
	 * integer parameter is created to distinquish
	 * between different entries on this array,
	 * which is 0 (i.e., the first) on
	 * construction.
	 * 
	 * @param user Fighter to which the Gear
	 * is assigned.
	 * @param name String name.
	 * @param level Integer value of the Gear's
	 * relative power.
	 * @param items String array of one or more 
	 * of the specific implements "expressed" as
	 * this instance of Gear.
	 */
	Gear(Fighter user, String name, int level, String[] items) {
		
		super(user, name, level);
		this.items = items;
		this.itemLevel = 0;
	}
	
	
	/**
	 * No-arg constructor for instances of the
	 * Gear class. Invokes the no-arg Fighter
	 * constructor, assigns a space as the 
	 * name, creates a String array only containing
	 * "None" for item names, and is level 0.
	 */
	Gear() {
		
		this((new Fighter()), "N/A", 0, new String[] {"None"});
	}
	
	
	/**
	 * Overrides the Stat levelName method
	 * to instead return the name of the current
	 * selection of the items parameter.
	 */
	String levelName() {
		
		return items[itemLevel];
	}

	
	/**
	 * Increments the itemLevel parameter,
	 * designating the next entry in the 
	 * "items" array as the new levelName.
	 * itemLevel cannot exceed the length
	 * of the array. Returns a boolean value
	 * based on whether or not the value
	 * increased, this in intended to be used
	 * by calling methods. However, the method
	 * can be treated as void if desired.
	 * 
	 * @return True if itemLevel increased,
	 * False otherwise.
	 */
	boolean upItem() {
		
		if (this.itemLevel < (this.items.length - 1)) {
			
			this.itemLevel++;
			
			return true;
		} else {
			
			return false;
		}
	}
	
	
	/**
	 * Prints a message containing the Strings of 
	 * the name parameter and the levelname method
	 * (which therefore includes the current item name),
	 * as well as the integer value of the level parameter.
	 * intended to used on status screens to display
	 * all relevant information of the Stat.
	 */
	void menuMessage() {
		
		System.out.printf("%-10s %-10s (Level %d)\n",(this.getName() + ":"),this.levelName(),this.getLevel());
	}
	
}
