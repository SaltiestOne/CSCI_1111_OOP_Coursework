/**
 * Class representing some quantifiable, if intangible,
 * aspect of a Fighter. Used for scaling Actions, as
 * well as various parameters and variables within the 
 * Main.
 * 
 * @author Kayden Barlow
 */
class Stat {
	
	private Fighter user;
	private String name;
	private int level;
	
	
	/**
	 * Constructor for instances of the Stat
	 * class. Must be assigned to an 
	 * instance of the Fighter class.
	 * Necessary to define instances of the
	 * Action class.
	 * 
	 * @param user Fighter to which the Stat
	 * is assigned.
	 * @param name String name.
	 * @param level Integer value of the Stat's
	 * relative power.
	 */
	Stat(Fighter user, String name, int level) {
		
		this.user = user;
		this.name = name;
		this.level = level;
	}
	
	
	/**
	 * No-arg constructor for instances of the
	 * Stat class. Invokes the no-arg Fighter
	 * constructor, assigns a space as the 
	 * name, and is level 0.
	 * 
	 */
	Stat() {
		
		this((new Fighter())," ",0);
	}
	
	
	/**
	 * Returns the reference for the instance
	 * of the Fighter class to which the Stat
	 * is assigned.
	 * 
	 * @return Fighter user of the Stat.
	 */
	Fighter getUser() {
		
		return this.user;
	}
	
	
	/**
	 * Returns the name of the Stat.
	 * 
	 * @return String Stat name.
	 */
	String getName() {
		
		return name;
	}
	
	
	/**
	 * Returns the "level" parameter
	 * of the Stat.
	 * 
	 * @return Integer level value.
	 */
	int getLevel() {
		
		return level;
	}
	
	
	/**
	 * Returns a "scaled" integer value
	 * derived from the level parameter of 
	 * both the Stat and its assigned Fighter, 
	 * equal to twice the level of the Stat
	 * plus the level of the user. This is 
	 * a deliberate choice, to make Stat investments
	 * matter more than simple level-ups.
	 * 
	 * @return Integer of user's level plus 
	 * two times the Stat's level.
	 */
	int getModdedLevel() {
		
		return ((this.level * 2) + user.getLevel());
	}
	
	
	/**
	 * Sets the level parameter to the 
	 * input integer value. Level cannot
	 * be negative. 
	 * 
	 * @param level Integer new value of
	 * level parameter.
	 */
	void setLevel(int level) {
		
		if (level < 0) {
			
			this.level = 0;
		} else {
	
			this.level = level;
		}
	}
	
	
	/**
	 * Increments the level parameter.
	 */
	void upLevel()	{
		
		this.level++;
	}
	
	
	/**
	 * Returns a String containing the 
	 * level of the Stat along with a
	 * descriptor of such.
	 *  
	 * @return String containing "Level"
	 * and the level of the Stat.
	 */
	String levelName() {
		
		return ("Level " + this.level);
	}
	
	
	/**
	 * Prints a message containing the Strings of 
	 * the name parameter and the levelname method,
	 * intended to used on status screens to display
	 * all relevant information of the Stat. I'd change
	 * it to output a formatted String but StringBuilder
	 * is scawy
	 */
	void menuMessage() {
		
		System.out.printf("%-10s %-10s\n",(this.getName() + ":"),this.levelName());
	}
	
	
}
