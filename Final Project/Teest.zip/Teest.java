import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

/**
 * Final project for the course
 * "Object-oriented Programming 1"
 * at Southwest Tech. Consists
 * of an endless turn-based RPG.
 * Requires the following object 
 * classes: "Fighter," "Monster,"
 * "Stat," "Gear," "Action,"
 * "Skill," "BasicAttack," and
 * "Spell." Designed to run in
 * compiler or system console.
 * 
 * @author Kayden Barlow
 * 
 */
public class Teest {

	public static void main(String[] args) {

		System.out.print("Welcome to Teest!\n\n");
		
		int round = 1;
		Fighter hero = new Fighter("Hero",round,1);
		Gear weapon = new Gear(hero, "Weapon", 0,
				new String[] {"Club", "Shortsword", "Longsword", "Katana"});
		Gear shield = new Gear(hero, "Off-hand", 0,
				new String[] {"Bare Hand", "Buckler", "Targe", "Heater"});
		Stat magic = new Stat(hero, "Magic", 0);
		BasicAttack basicAttack = new BasicAttack(weapon,"You swing your [i] at the [t],\n dealing [d] damage.");
		ArrayList<Action> skills = skillBuilder(weapon, shield);
		ArrayList<Action> spells = spellBuilder(magic);
		
		while (true) {
		//THE RIDE NEVER ENDS
			hero.setMaxHealth(((int)(10.5 * round) + 5 + shield.getLevel()),true);
			//sets hero's hp and restores it to full from previous fights
			Spell.setMaxMana(2 + (round * 2) + (magic.getLevel() * 3));
			Skill.setCooldown(0);
			//adjusts maximum mana and resets skill cooldown	
			Monster enemy = monsterMaker(round);
			//gives random enemy
			System.out.printf("You encounter a %s!\nPrepare for battle!\n",enemy.getName());
		
			while((hero.getHealth() > 0) && (enemy.getHealth() > 0)) {
				//main battle loop
				try { 
					
					battleScreen(enemy, hero);
					//current player/enemy HP values in a method
					switch (mainScreen()) {

					case 1: {
						//basic "normal" attack. uses the same method as Skills do 
						doTurn(basicAttack, enemy);
					break;
					}
				
					case 2: {
						//player status	
						System.out.printf("\nHero's level: %s\n",hero.getLevel());
						weapon.menuMessage();
						shield.menuMessage();
						magic.menuMessage();
					break;
					}
				
					case 3: {
						//enemy status	
						System.out.printf("\n%s's level: %d\nInfo:\n%s",
								enemy.getLevel(),enemy.healthGauge(),enemy.getFlavor());
						//hey kayden spend more time writing flavor text for the monsters
						//will do
					break;
					}	
					
					case 4: {
					//weapon/shield skill selection.
						if (Skill.isOnCooldown()) {
						//no skills can be used while the player is on cooldown.
							throw new IllegalArgumentException("Skills on cooldown!");
						} else {
							
							weapon.menuMessage();
							shield.menuMessage();
							
							System.out.println("\nAvailable skills:\n");
							
							doTurn((Skill)(actionMenu(skills)), enemy);
						}
					break;
					}
					
					case 5: {
					/*spell selection. since the bounded input is built into the main screen method, no check is 
					 needed to see if the player knows any spells before selecting this option.*/
						magic.menuMessage();
						
						System.out.printf("Mana: %s\n",Spell.manaGauge());
					
						System.out.print("Available spells:\n\n");
						
						doTurn(actionMenu(spells), enemy);
					break;
					}
					}	
				}
					
				catch (IllegalArgumentException ex) {
						
					System.out.println("\n\n\n" + ex.getMessage());	
				}
		}
		
		if (hero.getHealth() <= 0) {
			//riperoni
			battleScreen(enemy, hero);
			
			if (enemy.getHealth() <= 0) {
				//mutual-kill message
				System.out.printf("\nThe Hero has overcome the %s,\n but was overtaken all the same...\n",
						enemy.getName());
			} else {
				
				System.out.printf("\nThe Hero has failed in this battle,\n the %s is its victor...\n",
						enemy.getName());
			}
			
			System.exit(0);
		} else {}
		
			System.out.printf("You triumph over the %s!\n",enemy.getName());
			
			hero.setLevel(++round);
			//almost forgot about preincrements lol
			if (hero.getLevel() <= 16) {
				
				boolean error = true;
				
				do {

					try {

						statUp(upgrade(weapon, shield, magic, 5));
						
						error = false;
					}
						
					catch (IllegalArgumentException ex) {
						
						System.out.printf("\n\n\n%s\n\n",ex.getLocalizedMessage());
					}
				} while (error == true);
				
			} else {
				
				System.out.print("\nYour magic and gear are all at their peak!\n\n");
			}
		}
	}
	
	
	/**
	 * Display method that outputs a 
	 * visual overview of two Fighters,
	 * containing their name and health
	 * gauge within a box.
	 * 
	 * @param a Fighter to be displayed on
	 * the left side of the box.
	 * @param b Fighter to be displayed on
	 * the right side of the box.
	 */
	public static void battleScreen(Fighter a, Fighter b) {
		
		System.out.println("----------------+----------------");
		System.out.printf("%15s | %s\n%14s  |  %s\n",
				a.getName(),b.getName(),a.healthGauge(),b.healthGauge());
		System.out.println("----------------+----------------");
	}
	
	
	/**
	 * Display and prompt method
	 * that facilitates the main
	 * combat menu. Has prompts for
	 * the always-available options
	 * (basic attack, hero status, and
	 * enemy status) and for Skills and
	 * Spells, should they be usable.
	 * Input prompt makes use of the 
	 * "boundedInput" method.
	 * 
	 * @return Integer player selection.
	 */
	public static int mainScreen() {

		System.out.print("(1) Attack\t(2/3) Hero/Enemy Status\n");
		
		if (Skill.getCooldown() <= 0) {
			
			System.out.print("(4) Skills");
		} else {
			
			System.out.printf("Skill Cooldown: %d turns",Skill.getCooldown());
		}
		
		if (Spell.anyLearned()) {
			
			System.out.printf("\n(5) Spells (Mana: %s)\n",Spell.manaGauge());
			
			return boundedInput("Action: ",1,5);
		} else {
			
			if (Spell.manaSpent()) {
				//in case mana becomes a factor when the player has no spells
				System.out.printf("\t(Mana: %s)",Spell.manaGauge());
			} else {}
			
			return boundedInput("\n\nAction: ",1,4);
		}
	}
	
	/**
	 * Facilitates both the player
	 * and enemy actions for a single
	 * turn. Takes an instance of the
	 * Action class for the player, and
	 * and determines if it is usable.
	 * If it is usable, it is sent to
	 * the doAction method for execution.
	 * If it is not, the error message 
	 * for unusable Actions is thrown.
	 * If the Hero's turn is successfully
	 * completed, determines if the enemy
	 * scored a critical hit, performs
	 * its action, and then decrements 
	 * Skill Cooldown.
	 * 
	 * @param action Action for the Hero
	 * to attempt.
	 * @param enemy Monster to attack back.
	 */
	public static void doTurn(Action action, Monster enemy) {
		
		if (action.isUsable()) {
			
			doAction(action, enemy);
		} else {
				
			throw new IllegalArgumentException("Action unavailable!");
		}
		
		if ((new Random().nextInt(100)) < (8 + (2 * enemy.getLevel()))) {
		//enemy has a 10% initial chance to crit, which increases by 2 every subsequent level
			enemy.critical(action.getUser());
		} else {
			
			enemy.action(action.getUser());
		}
		
		Skill.dropCooldown();
	}
	
	/**
	 * Facilitates the individual effects
	 * of each Skill and Spell currently
	 * in the game. Each potential Action
	 * is constructed within other methods 
	 * such that it will have an ID value
	 * corresponding to a case in this 
	 * method's Switch statement. The 
	 * Action's user's level and the Action's 
	 * Stat's "Modded level" parameters are 
	 * internally stored as variables for
	 * convenience and readability, as 
	 * many Actions use one or both for
	 * scaling.
	 * 
	 * @param action Action to be used.
	 * @param target Monster to be targeted
	 * by the Action. May be irrelevant for
	 * some Action effects.
	 */
	public static void doAction(Action action, Monster target) {
	
		int heroLevel = action.getUser().getLevel();
		int statLevel = action.getStat().getModdedLevel();
		
		target.setDamage();
		
		switch (action.getId()) {
			
		case 1: {
		//The "Lunge" weapon Skill.	
			System.out.println(action.quickUse((Fighter.damage(heroLevel,((int)(statLevel * 1.5)))), target));
			//Lunge has a lower damage floor, but also a higher ceiling (to represent a desperation attack)
			if ((target.getHealth()) <= 0) {
			//if enemy is dead, they cannot mutual-kill	(unless they crit)
				target.stun();
			} else {}
		break;
		}
		
		case 2: {
		//The "Counter" shield Skill.	
			int damage = Fighter.damage(heroLevel);
				//has relatively weak scaling
			System.out.println(action.quickUse(damage, target));
		
			target.setDamage(target.getDamage() - damage);
		break;
		}
		
		case 3: {
		//The "Mana Burst" weapon Skill.	
			int manaCost = ((int)(Spell.getMaxMana() * .5));
			
			if (Spell.getMana() >= manaCost) {
				
				System.out.println(action.quickUse((Fighter.damage(((int)(statLevel * 1.5)),statLevel)), target));
				//scales very well
				Spell.spendMana(manaCost);
				
			} else if ((Action.getAction("Ascend")).isLearned()) {
				
				System.out.printf("You sacrifice %d health to abstract your %s,\n and strike for %d damage!\n",
						action.getUser().harm(Fighter.damage(heroLevel, statLevel)), action.getImplement(),
								target.harm(Fighter.damage(((int)(statLevel * 1.5)), statLevel)));
				//ah the wonders of not-actually-void methods
				((Skill)action).setCooldown();
				//shouldn't do anything but it just seemed proper
			} else {
				
				throw new IllegalArgumentException("No Mana to Burst.");
			}
		break;	
		}
		
		case 4: {
		//The "Shield Bash" shield Skill.
			System.out.println(action.quickUse(Fighter.damage(statLevel), target));
			
			if ((new Random().nextBoolean())) {
				
				target.stun();
				
				((Skill)action).setCooldown();
			} else {}
		break;	
		}
		
		case 5: {
		//The "Drain" Spell.
			
			int cure = Fighter.damage(heroLevel);
			//low floor and flux due to how good this spell is
			target.setDamage((target.getDamage()) - cure);
		
			System.out.println(action.getMessage((action.getUser().heal(cure)), target));
			
			((Spell)action).spendMana();
		break;
		}
		
		case 6: {
		//Bolt (attack spell)	
			System.out.println(action.quickUse(Fighter.damage(statLevel), target));
		break;
		}
		
		case 7: {
		//Ascend (health-for-mana spell)
			System.out.println(action.quickUse((Fighter.damage(heroLevel)),action.getUser()));
			//"trust no one, not even yourself"
			int upMana = (int)(Spell.getMaxMana() * .5);
			
			Spell.upMana(upMana);
			
			System.out.printf(" restoring %d Mana!\n",upMana);
		break;
		}
		
		case 8: {
		//Revert spell	
			int damage = Fighter.damage((statLevel + action.getStat().getLevel()),heroLevel);
			
			System.out.print(action.getMessage(damage));
			
			action.getUser().heal(damage);
			
			((Spell)action).spendMana();
		break;
		}
		
		case 9: {
		//Astra spell
			int stars = (new Random().nextInt((Spell.getMana()) / (action.getCost())) + 1);
			
			if (stars <= 0) {
				
				System.out.println("The stars cross against the Hero!\n No damage dealt...");
				//spell has a chance to fail.
			} else {
			
				int damage = 0;
				
				for (int s = 0; s < stars; s++) {
					
					damage += (Fighter.damage(1, (int)(statLevel * 2.5)));
				}
				
				System.out.printf("%d%s\n", stars, ((Spell)action).quickUse(damage, target));
				
				Spell.spendMana((stars - 1) * action.getCost());
				//spends the extra mana from the additional stars
			}	
	
		break;	
		}
		
		default: {
		//intended for the basic attack
			System.out.println(action.quickUse(Fighter.damage(statLevel), target));
		break;
		}
		
		} 
	}
	
	
	/**
	 * Displays the input list of
	 * instances of the Action object
	 * class. Each is shown individually
	 * in a numbered list, either displaying
	 * its Action.menuMessage() String if
	 * it is learned, or "[UNLEARNED]" if
	 * it is not. A cancel option is added
	 * after all Action entries are listed.
	 * Implements the boundedInput method
	 * to get a prompt no larger than the list. 
	 * Either returns the Action corresponding
	 * to the input, or throws an error if
	 * the input was either out of bounds
	 * or the "cancel" option. This method
	 * displays if an Action is unlearned, 
	 * but does not prevent inputs that would
	 * return an unusable Action. Thus,
	 * errors for attempting to use an 
	 * unusable Action must be thrown by
	 * other methods.
	 * 
	 * @param actionList ArrayList<Action> of
	 * all Actions to be listed.
	 * @return Action corresponding to received
	 * input.
	 */
	public static Action actionMenu(ArrayList<Action> actionList) {

		if (listUnlearned(actionList)) {

			throw new IllegalArgumentException("None Learned!");
		} else {

			for (int l = 0; l < actionList.size(); l++) {
				
				if (actionList.get(l).isLearned()) {
			
					System.out.printf(" (%d) %s\n",(l + 1),actionList.get(l).menuMessage());
				} else {
					
					System.out.println(" [UNLEARNED]");
				}
			}
			//a handy "cancel" option after the normal selections.
			System.out.printf(" (%d) Cancel\n\n",(actionList.size() + 1));
		}
		
		int choice = (boundedInput("Selection: ",1,(actionList.size() + 1)));
		
		if (choice > actionList.size()) {
			
			throw new IllegalArgumentException("Selection Canceled.");
			//feels wrong since this isn't really an "error" but hey
		} else {
			
			return actionList.get(choice - 1);
		}
	}
	
	
	/**
	 * Facilitates increasing Stat objects.
	 * Three Stat objects are listed, and
	 * the boundedInput method is invoked
	 * to get an input corresponding to one
	 * of them. If the input is in bounds,
	 * and the Stat's level paramter is 
	 * within the value defined as "max," 
	 * it is output for other methods to 
	 * process.
	 * 
	 * @param a Stat of first upgrade option.
	 * @param b Stat of second upgrade option.
	 * @param c Stat of third upgrade option.
	 * @param max Integer of the maximum
	 * allowed level parameter of a Stat.
	 * @return Stat selected by prompted input.
	 */
	public static Stat upgrade(Stat a, Stat b, Stat c, int max) {
		
		Scanner input = new Scanner(System.in);
		boolean error = false;
		int choice = 0;
		Stat[] options = {a, b, c};
		
		do {
		
			error = false;
			
			try {
			
				System.out.printf("You may upgrade one of these:\n\n");
			
				for (int n = 0; n < 3; n++) {
				
					System.out.printf("(%d) ",(n + 1));
					options[n].menuMessage(); 
				}

				choice = (boundedInput("\nChoose one: ",1,3) - 1) ;
				
				if (options[choice].getLevel() >= max) {
					
					throw new IllegalArgumentException("Already at max!\n");					
				} else {}
			}
			
			catch (IllegalArgumentException ex) {
			
				throw ex;
			}

		} while (error == true);
		
		return options[choice];
	}
	
	
	/**
	 * Increments an input Stat object's
	 * level parameter and potentially
	 * learns an Action associated with
	 * the Stat (facilitated by the
	 * learnAction method). Displays 
	 * a message if a new Action was 
	 * learned, or if a Gear object
	 * had its implement name changed.
	 * 
	 * @param stat Stat to increment.
	 */
	public static void statUp(Stat stat) {
		
		if (stat instanceof Gear) {
			
			if ((stat.getLevel() % 2) == 0) {
				
				if (((Gear)stat).upItem()) {
					
					System.out.printf("\nYour %s is now a %s!\n\n",stat.getName(),stat.levelName());
				} else {
					//failsafe in case someone levels higher than there are gear names.
					System.out.printf("\nYou further hone your %s.\n\n",stat.getName());
				}
			} else {
				
				System.out.printf("\nYou learn how to do a %s!\n\n",
						(learnAction(stat,Action.getList())).getName());
			}	
		} else {

			System.out.printf("\nYou learn how to cast %s!\n\n",
					(learnAction(stat,Action.getList())).getName());
		}
		//we now conclude the Yandev portion of the game's code.
		stat.upLevel();
	}
	
	
	/**
	 * Searches any input ArrayList
	 * for an unlearned Action associated 
	 * with an input Stat object. The 
	 * first time it finds one, it marks
	 * the Action learned and returns it.
	 * If no Actions are found that meet
	 * the criteria, throws an error.
	 * 
	 * @param stat Stat associated with
	 * target Action.
	 * @param actionList ArrayList<Action>
	 * to be searched.
	 * @return Action found and marked
	 * learned by this method.
	 */
	public static Action learnAction(Stat stat, ArrayList<Action> actionList) {
		
		for (int a = 0; a < actionList.size(); a++ ) {
			
			Action current = actionList.get(a);
			
			if ((current.getStat() == stat) && (!(current.isLearned()))) {
				
				current.learn();
				
				return current;
			} else {}
		}
		
		throw new IllegalArgumentException("Stat at max level!");
	}

	
	/**
	 * Constructs all instances of the
	 * Skill class currently in the game.
	 * Since both the "weapon" and "off-hand"
	 * Gear Stats are used for Skills,
	 * both are parameters. Arrays for 
	 * the name, message, and cooldown
	 * parameters are grabbed by a for-loop.
	 * This loop also alternates between
	 * the two input Gears. Outputs all
	 * created Skills in an ArrayList,
	 * for convenience. I COULD have written
	 * a static "filter" method to search
	 * the "allAction" master list but
	 * I just want to get this course done
	 * 
	 * @param weapon Gear used to construct the
	 * odd-numbered Skills on the output list.
	 * @param offhand Gear used to construct the
	 * even-numbered Skills on the output list.
	 * @return ArrayList<Action> containing
	 * all Skills created by this method.
	 */
	public static ArrayList<Action> skillBuilder(Gear weapon, Gear offhand) {
		
		ArrayList<Action> list = new ArrayList<Action>();
		
		Gear gear = weapon;
		
		int[] cooldowns = {3, 2, 1, 2};
		
		String[] name = {"Lunge","Counter","Mana Burst","Shield Bash"};
		
		String[] message = {"You lunge at the [t] with your [i],\n dealing [d] damage!",
				"While your [i] breaks the [t]'s assault,\n you swing for [d] damage.",
				"You channel Mana into your [i] and strike the [t],\n dealing [d] damage!",
				"You slam your [i] into the [t],\n dealing [d] damage!"};
		
		for (int s = 0; s < 4; s++) {
			
			Skill newSkill = new Skill(name[s], cooldowns[s], gear, message[s], false);
			
			list.add(newSkill);
			
			if (gear == weapon) {
			//alternates between the two stats	
				gear = offhand;
			} else {
				
				gear = weapon;
			}
		}
		
		return list;
	}
	
	
	/**
	 * Constructs all instances of the
	 * Spell class currently in the game.
	 * Arrays for the name, message, and cost
	 * parameters are grabbed by a for-loop.
	 * Outputs all created Spells in an ArrayList,
	 * for convenience. I COULD have written
	 * a static "filter" method to search
	 * the "allAction" master list but
	 * I just want to get this course done
	 * 
	 * @param magic Stat used to construct
	 * all Spells in the method.
	 * @return ArrayList<Action> containing
	 * all Spells created by this method.
	 */
	public static ArrayList<Action> spellBuilder(Stat magic) {
		
		ArrayList<Action> list = new ArrayList<Action>();
		
		int[] costs = {4, 2, 0, 8, 5};
		
		String[] name = {"Drain","Bolt","Ascend","Revert","Astra"};
		
		String[] message = {"You drain Mana from the [t],\n restoring [d] health!",
				"You send a flare of energy towards the [t],\n dealing [d] damage!",
				"You abstract [d] points of lifeforce,",
				"You channel magic into yourself,\n restoring [d] health.",
				" of the stars cross the [t],\n dealing [d] damage!",};
		
		for (int s = 0; s < 5; s++) {
			
			Spell newSpell = new Spell(name[s], costs[s], magic, message[s], false);
		
			list.add(newSpell);
		}
		
		return list;
	}
	
	
	/**
	 * Method that determines if
	 * any Actions on an input list
	 * are marked as learned.
	 * 
	 * @param list ArrayList<Action> to
	 * be checked.
	 * @return True if at least one Action
	 * on the input ArrayList is learned,
	 * False if none are.
	 */
	public static boolean listUnlearned(ArrayList<Action> list) {
		
		for (int a = 0; a < list.size(); a++) {
			
			if (list.get(a).isLearned()) {
				
				return false;
			} else {}	
		}
		
		return true;
	}
	
	
	/**
	 * Prompts the user for an integer and then
	 * determines if it falls within certain bounds.
	 * Returns valid inputs, throws an error if the
	 * input is too small or large.
	 * 
	 * @param prompt String of the prompt that will be displayed 
	 * to the user.
	 * @param min Integer value of the smallest possible value
	 * that will be accepted.
	 * @param max Integer value of the largest possible value
	 * that will be accepted.
	 * @return The integer entered by the user, if no error 
	 * was thrown.
	 */
	public static int boundedInput(String prompt, int min, int max) {
		
		Scanner input = new Scanner(System.in);
		//currently the only input in the whole game, all menus call for this method.
		System.out.print(prompt);

		int result = input.nextInt();
			
		if ((result < min) || (result > max)) {
				
				throw new IllegalArgumentException("Invalid input.");
			} else {
				
				return result;
			}
	}
	
	
	/**
	 * Outputs a Monster object randomly selected
	 * from a prewritten list of potential instances.
	 * Randomly generates a number affected and bound by the 
	 * current round, which allows different monsters
	 * to possibly appear as the game goes on. The 
	 * corresponding row of the multi-array with 
	 * all possible monster types is selected and used for
	 * the Monster's "flavor" parameter.
	 * The round value is then used for the monster's
	 * level, and used to scale the monster's max HP.
	 * 
	 * @param round Integer value of the current round of
	 * game.
	 * @return An instance of the Monster object,
	 * created with randomized flavor and scaled level and
	 * HP.
	 */
	public static Monster monsterMaker(int round) {
		
		String[][] monsters = { 
				{"Rat", "bites", "chomps", 
					"Not even a big one. It's, like, a foot from nose to tail.",
					"It's only trouble because it's so hard to hit."}, 
				{"Tree Snake", "bites", "lunges at", 
					"Mostly eats small animals. Lays on treetops for warmth.",
					"Attacks in self-defense if knocked off the branches."}, 
				{"Half-Skeleton", "tackles", "strangles", 
					"Shambles around missing an arm, its feet, and some ribs.",
					"Crawls on 'all threes' and throws itself at threats."},
				{"Lone Wolf", "bites", "pounces on", 
					"Usually, the lone wolves are that way for a reason.",
					"This one MIGHT just be misunderstood. But I doubt it."},
				{"Baby Chimera", "rams into", "pins", 
					"Chimeras born in the wild start off relatively weak.",
					"Coordinating all their different parts takes practice."},
				{"Wolfrat", "bites", "gouges",
					"Despite the name, they're a carnivorous cousin of rabbits.",
					"But a layman could assume them to be wolf-rat hybrids."},
				{"Poacher", "shoots at", "entraps",
					"'Poacher' is used euphamistically.",
					"Illegal hunting is a lesser crime than others."},
				{"Dozentalon", "scrapes", "pounces on",
					"Bird of prey with large wings and two pairs of clawed limbs.",
					"A famous poem asks, 'Be a dragon, or a gryphon, that bird?'"},
				{"Ice-Mote", "chills", "freezes",
					"Is it an Air or Water Elemental? Both? Neither?",
					"Many arcanologists have lost friendships over this debate."},
				{"Female Bandit", "chops", "sacks",
					"Has many cheap romance novels hidden under her loot stash.",
					"A hostage nobleman falls for his captor in most of them."},
				{"Green Slime", "splashes", "corrodes",
					"Orcs love these, and eat them raw like in the stories.",
					"Half-orcs hate these, because of stereotypes."},
				{"Catalin Daerg", "stabs", "runs through",
					"This fae warrior appears as a green knight with spears for arms.",
					"Having no mouth, it's easily the most trustworthy type of fairy."},
				{"Refuse Golem", "tosses", "lays waste to",
					"One can really get their mana's worth out of one of these.",
					"They're not only cheaper than other golems, but scarier too."},
				{"Earth Angel", "dusts", "buries",
					"A lizard that hosts special Earth Elementals on its skin.",
					"These envelop the creature in a mass of soil, sand, or clay."},
				{"Haunted Blade", "slashes at", "lacerates", 
					"A worn, discarded sword possessed by a resentful spirit.",
					"Perhaps they, too, felt like an unwanted weapon."},
				{"Edge-Lord", "bleeds", "scars", 
					"Some are mockingly called \"Lords\" of the \"Edge\" of society.",
					"Most are people who traded their morals for power of some kind."},
				{"Blue Wyvern", "snatches", "chomps",
					"This subspecies's breath \"weapon\" isn't harmful; it regulates heat.",
					"This lets it survive in more enviornments than any of its cousins."},
				{"Swordist", "counters", "lunges at",
					"A catch-all term for proficient users of a sword and shield.",
					"A mercenary, bandit, guard... whichever happens to be fighting you."},
				{"Paladin", "shield-bashes", "casts Bolt on",
					"One who uses a shield and magic to defend... something.",
					"Sanctioned holy warriors are called this only as an insult."},
				{"Battle-Mage", "strikes", "Mana-Bursts",
					"Student of both martial and arcane arts, out to prove something.",
					"Channels various spells through an overdesigned two-handed weapon."},
				{"False Phoenix", "singes", "roasts",
					"A bird that creates fire to assist with flight, hunting, and defense.",
					"Known by other names in places without a concept of a \"phoenix.\""},
				{"Wheelchair Drake", "rolls into", "yuhs",
					"Congrats. You're clearly strong enough and lucky enough.",
					"You've earned the right to fight the token joke enemy."},
				{"Hero's Shadow", "mimics", "nullifies",
					"None can deafeat their own shadow, only hold it back.",
					"And sometimes, it becomes more popular than its original."}
		};
		
		int result = 0;
		
		do {
		
			result = ((new Random().nextInt(4 + (int)(1.2 * round)) + (round - 1)));
		
		} while (result >= (monsters.length)); 
		//ensures that no out-of-bounds occurs as round exceeds the length of the database
		return new Monster(monsters[result],round,((14 * round) + 1));
	}
}