import java.util.ArrayList;

/**
 * A subclass of Action intended to represent "martial manuevers" that use a 
 * specific armament. The static integer "cooldown" represents the Hero
 * being unable to use Skills for a certain number of turns after 
 * the use of another.
 * 
 * @author Kayden Barlow
 */
class Skill extends Action {
	
	private static int cooldown = 0;
	
	/**
	 * Constructor for "permanent" instances 
	 * of the Skill object. Differs from its
	 * parent's constructor only in requiring
	 * that a Gear object is entered in the Stat
	 * parameter.
	 * 
	 * @param name String of the Skill's name.
	 * @param cooldown Integer for the Skill's cooldown. (This is this
	 * Action's "cost" value.)
	 * @param gear Gear object from which the Skill's scaling is derived.
	 * @param message String of the text which will be displayed when the Skill
	 * is used. Placeholders for the implement, target, and damage when used are
	 * [i], [t], and [d] respectively and are replaced by output methods.
	 * @param learned Boolean value indicating if the player has "learned" this
	 * Skill after its creation. If False, the Skill cannot be used regardless 
	 * of other factors.
	 */
	Skill(String name, int cooldown, Gear gear, String message, boolean learned) {
		
		super(name, cooldown, gear, message, learned);
	}
	
	
	/**
	 * Constructor for "incidental" instances
	 * of the Skill object. Differs from its
	 * parent's constructor only in requiring
	 * that a Gear object is entered in the Stat
	 * parameter.
	 * 
	 * @param name String of the Skill's name.
	 * @param id Integer identifying number of the Skill.
	 * @param cooldown Integer for the Skill's cooldown. (This is this
	 * Action's "cost" value.)
	 * @param gear Gear object from which the Skill's scaling is derived.
	 * @param message String of the text which will be displayed when the Skill
	 * is used. Placeholders for the implement, target, and damage when used are
	 * [i], [t], and [d] respectively and are replaced by output methods.
	 */
	Skill(String name, int id, int cooldown, Gear gear, String message) {
		
		super(name, id, cooldown, gear, message);
	}
	
	
	/**
	 * No-arg Skill constructor. Invokes the 
	 * arguments of the "incidental"
	 * constructor.
	 */
	Skill() {
		
		this("N/A", 0, 0, (new Gear()), "None");
	}
	
	
	/**
	 * Overrides the abstract superclass method to give the name
	 * of the "armament" (as specified in the associated Gear
	 * object) used by the Skill, rather than a general Stat name.
	 * 
	 * @return String name of the specific "piece" of Gear used by the Skill.
	 */
	String getImplement() {
	
		return this.getStat().levelName();
	}
	
	/**
	 * If this Skill is marked learned, returns
	 * a String containing the Skill's name, its 
	 * current implement (as defined by its Gear 
	 * parameter), and its Cooldown cost. If it
	 * is not learned, returns "[UNLEARNED]".
	 */
	String menuMessage() {
		
		if (this.isLearned()) {
			
			return (this.getName() + " (" + this.getImplement() + 
				", Cooldown " + (this.getCost() -1) + ")");
		} else {
			
			return ("[UNLEARNED]");
		}
	}
	
	/**
	 * Returns the static integer representing
	 * the number of turns remaining until
	 * another Skill can be used.
	 * 
	 * @return Integer value of cooldown.
	 */
	static int getCooldown() {
		
		return cooldown;
	}
	
	/**
	 * Returns a static boolean indicating if
	 * cooldown is a positive value, and therefor
	 * that Skills are on cooldown.
	 * 
	 * @return True if cooldown is greater than
	 * zero, False if it is zero (or less, somehow).
	 */
	static boolean isOnCooldown() {
		
		if (cooldown <= 0) {
			
			return false;
		} else {
			
			return true;
		}
	}
	
	
	/**
	 * Indicates if this Skill can be used.
	 * If Skills are on Cooldown, or if
	 * this instance is unlearned, it is 
	 * not Usable and returns False. Otherwise,
	 * returns True.
	 */
	boolean isUsable() {
		
		return ((!isOnCooldown()) && this.isLearned());
	}
	
	
	/**
	 * Increases Cooldown by this Skill's cooldown
	 * parameter. This is equivalent to setting
	 * it to the value in practice, save that if, 
	 * for whatever reason, a Skill with a cooldown
	 * cost is used while Skills are on cooldown,
	 * this will not reduce remaining cooldown to
	 * a lesser value.
	 */
	void setCooldown() {
		
		cooldown += (this.getCost());	
	}
	
	
	/**
	 * Sets Cooldown to the specified value.
	 * Cooldown cannot be negative.
	 * 
	 * @param cooldown Integer new Cooldown.
	 */
	static void setCooldown(int cooldown) {
		//increases cooldown to a set amount
		if (cooldown >= 0) {
			
			Skill.cooldown = cooldown;
		} else {
			
			Skill.cooldown = 0;
		}
	}
	
	
	/**
	 * Invokes its sister method to drop
	 * Cooldown by 1. Intended to be invoked at
	 * the end of every turn.
	 */
	public static void dropCooldown() {
		
		Skill.dropCooldown(1);
	}
	
	
	/**
	 * Reduces Cooldown value by the input
	 * amount. Cooldown cannot be negative.
	 * 
	 * @param decrement Integer amount to reduce
	 * Cooldown.
	 */
	static void dropCooldown(int decrement) {
		//decreases by a set amount, not to a negative value
		if ((cooldown - decrement) >= 0) {
		
			cooldown -= decrement;
		} else {
			
			cooldown = 0;
		}
	}
	
	
	/**
	 * Consolidates damaging a target with a Skill (using
	 * the integer and Fighter input values), setting its 
	 * Cooldown, and generating its output message 
	 * (also using the inputs). This message is output,
	 * not directly printed, in order to give formatting 
	 * control to invoking methods.
	 */
	String quickUse(int damage, Fighter target) {
		
		this.setCooldown();
		
		return this.getMessage(target.harm(damage), target);
	}
}
