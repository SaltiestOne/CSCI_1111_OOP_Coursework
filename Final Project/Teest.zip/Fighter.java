import java.util.Random;


/**
 * Represents a participant in combat of some
 * kind. This could be anyone, but is only used
 * for the Hero in Teest.
 * 
 * @author Kayden Barlow
 */
class Fighter {
	
	private String name;
	private int level;
	private int maxHealth;
	private int health;
	
	/**
	 * Constructor for instances of the Fighter
	 * class. On construction, the integer
	 * health parameter will be equal to
	 * the maximum health parameter.
	 * 
	 * @param name String name of the Fighter.
	 * @param level Integer value of the 
	 * Fighter's relative power.
	 * @param maxHealth Integer value of the 
	 * Fighter's maximum health points.
	 */
	Fighter(String name, int level, int maxHealth) {
		
		this.name = name;
		this.level = level;
		this.maxHealth = maxHealth;
		this.health = maxHealth;
	}
	
	
	/**
	 * No-arg constructor for instances of the
	 * Fighter class. Sets the name parameter
	 * to a space, level to 0, and 
	 * maximum/current health to 1.
	 * 
	 * 
	 */
	Fighter() {
		
		this.name = " ";
		this.level = 0;
		maxHealth = health = 1;
	}
	
	
	/**
	 * Returns the String of the
	 * Fighter's name parameter.
	 * 
	 * @return String name of the Fighter.
	 */
	public String getName() {
		
		return name;
	}
	
	
	/**
	 * Returns the integer value of the 
	 * Fighter's level parameter.
	 * 
	 * @return Level of the Fighter.
	 */
	public int getLevel() {
		
		return level;
	}
	
	
	/**
	 * Increments the Fighter's current
	 * level parameter.
	 * 
	 */
	public void setLevel() {
		
		level++;
	}
	
	
	/**
	 * Sets the Fighter's level to the 
	 * input integer. Level cannot
	 * be negative.
	 * 
	 * @param level Integer value of 
	 * new level.
	 */
	public void setLevel(int level) {
		
		if (level <= 0) {
			
			level = 0;
		} else {
			
			this.level = level;
		}
	}
	
	
	/**
	 * Returns the integer value of the
	 * Fighter's maximum health parameter.
	 * 
	 * @return Integer value of the 
	 * Fighter's maximum health.
	 */
	public int getMaxHealth() {
		
		return maxHealth;
	}
	
	
	/**
	 * Adjusts the Fighter's maximum
	 * health parameter to the input amount.
	 * Maximum health cannot be negative.
	 * If current health exceeds the new value,
	 * or if the boolean input is set to "True"
	 * (the latter is intended as "full heal"
	 * as part of a level-up), then health
	 * is set equal to the value of maximum
	 * health.
	 * 
	 * @param maxHealth Integer value of the
	 * new maximum health.
	 * @param heal If True, health parameter
	 * is made equal to maximum.
	 */
	public void setMaxHealth(int maxHealth, boolean heal) {
		
		if (maxHealth < 0) {
			
			maxHealth = 0;
		} else {}
		
		this.maxHealth = maxHealth;
		
		if ((heal = true) || (health > maxHealth)) {
			
			setHealth(maxHealth);
		} else {}
	}
	
	
	/**
	 * Returns the integer value of the
	 * Fighter's current health parameter.
	 * 
	 * @return Integer value of the Fighter's
	 * health.
	 */
	public int getHealth() {
		
		return health;
	}

	
	/**
	 * Adjusts the Fighter's health parameter
	 * to the input integer. Health cannot
	 * be negative or exceed the Fighter's 
	 * maximum health parameter.
	 * 
	 * @param health Integer value of the
	 * Fighter's new health parameter.
	 */
	public void setHealth(int health) {
		
		if (health > this.maxHealth) {
			
			health = this.maxHealth;
		} else if (health < 0) {
			
			health = 0;
		}
		
		this.health = health;
	}
	
	
	/**
	 * Returns a String displaying 
	 * max and current health, intended for
	 * menus and such.
	 * 
	 * @return A String with the current and max health,
	 * seperated by a slash.
	 */
	public String healthGauge() {

		return (health + "/" + maxHealth);
			
	}
	
	
	/**
	 * Returns a random integer generated
	 * according to the input integer, intended 
	 * to be used for Action scaling. The
	 * "floor" of the output, equal to the input, 
	 * is the mimimum output value. The 
	 * "fluctuation" value, adds one-fourth
	 * the input (rounded down) to the set
	 * number 6 to determine the range of
	 * the random numbers possible. Fluctuation
	 * is reduced in this way in order to slowly 
	 * increase the range of possible values
	 * as scalers increase. This method is 
	 * used instead of its two-arg sister
	 * in cases where the floor and 
	 * fluctuation are equal.
	 * 
	 * @param mod Integer minimum of the output.
	 * @return Random integer, scaled according 
	 * to above formula.
	 */
	static int damage(int mod) {
		//yes im making this static to make some methods easier, this wouldn't work if there were more than one player
		return Fighter.damage(mod,mod);
		
	}
	
	
	/**
	 * Returns a random integer generated
	 * according to two factors, intended to
	 * be used for Action scaling. The first,
	 * the "floor" integer, is the mimimum
	 * output value. The second, the
	 * "fluctuation" value, adds one-fourth
	 * of itself (rounded down) to the set
	 * number 6 to determine the range of
	 * the random numbers possible. Fluctuation 
	 * is reduced in this way in order to slowly 
	 * increase the range of possible values
	 * as scalers increase. For this reason,
	 * the fluctuation value should just be 
	 * the Hero's level in most cases.
	 * 
	 * @param floor Integer minimum output.
	 * @param fluctuation Integer used to adjust
	 * range of outputs.
	 * @return Random integer, scaled according 
	 * to above formula.
	 */
	static int damage(int floor, int fluctuation) {
		
		return ((new Random().nextInt(6 + (int)(fluctuation * 0.25))) + floor);
	}
	
	
	/**
	 * Reduces this Fighter's health parameter
	 * by the input amount. Health cannot be 
	 * negative. Output is identical to the input,
	 * intended for consolidation of methods that 
	 * display (or otherwise use the damage number)
	 * with the effect of this method. If only the
	 * effect and not the output are desired, 
	 * the method can be used as if it were void.
	 * 
	 * @param damage Integer reduction to Fighter's
	 * health parameter.
	 * @return Integer identical to input.
	 */
	int harm(int damage) {
		
		health -= damage;
		
		if (health  < 0) {
			
			health = 0;
		} else {}
		
		return damage;
	}
	
	
	/**
	 * Increases this Fighter's health parameter
	 * by the input amount. Health cannot go above
	 * the Fighter's maximum health parameter. 
	 * Output is identical to the input,
	 * intended for consolidation of methods that 
	 * display (or otherwise use the cure number)
	 * with the effect of this method. If only the
	 * effect and not the output are desired, 
	 * the method can be used as if it were void.
	 * 
	 * @param damage Integer increase to Fighter's
	 * health parameter.
	 * @return Integer identical to input.
	 */
	int heal(int cure) {
		
		health += cure;
		
		if (health > maxHealth) {
			
			health = maxHealth;
		} else {}
		
		return cure;
	}
}