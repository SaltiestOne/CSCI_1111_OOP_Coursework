/**
 * A subclass of Action intended to represent
 * the various magical spells that the Hero can
 * cast. Uses a classic "Mana" system, where
 * an amount of resource is available at the
 * start of a fight, with different Spell
 * objects costing a specified amount of it.
 * 
 * @author Kayden Barlow
 */
class Spell extends Action {
	
	private static int maxMana;
	private static int mana;
	
	
	/**
	 * Constructor for "permanent" instances of
	 * the Spell object.
	 * 
	 * @param name String of the Spell's name.
	 * @param manaCost Integer of the amount of Mana spent by the Spell.
	 * @param gear The Stat object from which the Spell's scaling is derived.
	 * @param message String of the text which will be displayed when the Spell
	 * is used. Placeholders for the implement, target, and damage when used are
	 * [i], [t], and [d] respectively and are replaced by output methods.
	 * @param learned Boolean value indicating if the player has "learned" this
	 * Spell after its creation. If False, the Spell cannot be used regardless 
	 * of other factors.
	 */
	Spell(String name, int manaCost, Stat stat, String message, boolean learned) {
		
		super(name, manaCost, stat, message, learned);
	}
	
	
	/**
	 * Constructor for "incidental" instances of
	 * the Spell object.
	 * 
	 * @param name String of the Spell's name.
	 * @param id Integer identifying number of the Spell.
	 * @param manaCost Integer of the amount of Mana spent by the Spell.
	 * @param gear Stat object from which the Spell's scaling is derived.
	 * @param message String of the text which will be displayed when the Spell
	 * is used. Placeholders for the implement, target, and damage when used are
	 * [i], [t], and [d] respectively and are replaced by output methods.
	 */
	Spell(String name, int id, int cost, Stat stat, String message) {
		
		super(name, id, cost, stat, message);
	}
	
	/**
	 * If this Spell is marked learned, returns
	 * a String containing the Spell's name and 
	 * Mana cost. If this Spell's cost exceeds
	 * current available Mana, a message indicated
	 * such replaces the cost component of the
	 * String. If this Spell is unlearned, returns
	 * "[UNLEARNED]".
	 */
	String menuMessage() {
		
		if (this.isLearned()) {
			
			if (this.getCost() <= mana) {
			
				return (this.getName() + " (Mana cost: " + this.getCost() + ")");
			} else {
			
				return (this.getName() + " (Insufficient Mana!)");
			}
		} else {
			
			return ("[UNLEARNED]");
		}
	}
	
	
	/**
	 * Indicates if this Spell can be used.
	 * If this Spell costs more mana than is 
	 * available, or if it is unlearned,
	 * returns False. Otherwise, returns True.
	 */
	boolean isUsable() {
		
		if (mana >= this.getCost()) {
			
			return this.isLearned();
		} else {
			
			return false;
		}
	}
	
	
	/**
	 * Returns the static value indicating
	 * the Hero's maximum Mana.
	 * 
	 * @return Integer maximum Mana.
	 */
	static int getMaxMana() {
		
		return maxMana;
	}
	
	
	/**
	 * Adjusts the static maximum Mana
	 * value to the input integer. Also
	 * sets current mana to the same value.
	 * Intended to scale the Hero's 
	 * maximum Mana up at the start of each
	 * round.
	 * 
	 * @param maxMana Integer of the new
	 * maximum Mana value.
	 */
	static void setMaxMana(int maxMana) {
		
		Spell.maxMana = mana = maxMana;
	}
	
	
	/**
	 * Returns the integer value of the
	 * Hero's available Mana.
	 * 
	 * @return Integer of available Mana.
	 */
	static int getMana() {
		
		return mana;
	}
	
	
	/**
	 * Attempts to reduce current Mana by
	 * this Spell's cost value. Invokes the
	 * static Spell method, which throws an
	 * exception if cost exceeds current mana.
	 */
	void spendMana() {

		spendMana(this.getCost());
	}
	
	
	/**
	 * Attempts to reduce current Mana by
	 * the input amount. Exception is thrown 
	 * if the input amount exceeds available Mana.
	 * 
	 * @param amount Integer reduction in current Mana.
	 */
	static void spendMana(int amount) {
		
		if (amount > mana) {
			
			throw new IllegalArgumentException("Insufficient mana!");
		} else {
			
			mana -= amount;
		}
	}
	
	
	/**
	 * Invokes the setMana method to
	 * increase the current Mana by the 
	 * input Mana. Will not exceed the
	 * maximum Mana value.
	 * 
	 * @param amount Integer to be added 
	 * to available Mana.
	 */
	static void upMana(int amount) {
		
		setMana(mana + amount);
	}
	
	
	/**
	 * Sets the currently available Mana
	 * to the input amount. This cannot be
	 * negative, or exceed the maximum Mana 
	 * value.
	 * 
	 * @param mana Integer new Mana value.
	 */
	static void setMana(int mana) {
		
		if (mana > maxMana) {
			
			Spell.mana = maxMana;
		} else if (mana <= 0) {
			
			Spell.mana = 0;
		} else {
		
			Spell.mana = mana;
		}
	}
	
	
	/**
	 * Indicates if current Mana is less
	 * than maximum.
	 * 
	 * @return False if current and maximum
	 * Mana are equal, True otherwise.
	 */
	static boolean manaSpent() {
		
		if (mana < maxMana) {
			
			return true;
		} else {
			
			return false;
		}
	}
	
	
	/**
	 * Returns a String containing both
	 * current and maximum mana, intended
	 * for menus and such.
	 * 
	 * @return Available and maximum Mana
	 * values, seperated by a slash.
	 */
	static String manaGauge() {
		
		return (mana + "/" + maxMana);
	}
	
	
	/**
	 * Consolidates damaging a target with a Spell (using
	 * the integer and Fighter input values), spending 
	 * its Mana cost, and generating its output message 
	 * (also using the inputs). This message is output,
	 * not directly printed, in order to give formatting 
	 * control to invoking methods.
	 */
	String quickUse(int damage, Fighter target) {
	
		this.spendMana();
		
		return this.getMessage(target.harm(damage), target);
	}
	
	
	/**
	 * Indicates if any instances of the Spell
	 * class on the "allAction" ArrayList are 
	 * marked learned. 
	 * 
	 * @return True if there is at least one Spell
	 * marked learned, False otherwise.
	 */
	static boolean anyLearned() {
		
		for (int a = 0; a < Action.totalActions(); a++) {
			
			Action current = Action.findAction(a);
			
			if ((current instanceof Spell) && current.isLearned()) {
				
				return true;
			} else {}
		}
		
		return false;
	}
}